#include<iostream>
using namespace std;
int main()
{
	float a;
	cin>>a;
	for (int i=1;i<=10;i++)
	{
		cout<<"\n"<<a*i;
	}
}
